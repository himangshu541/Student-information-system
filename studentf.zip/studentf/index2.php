<!DOCTYPE html>
<html lang="en">
<head>
<title>Student Information</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.4.2.min.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_300.font.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_400.font.js"></script>
<script type="text/javascript" src="js/script.js"></script>

</head>
<body id="page1">
<!-- START PAGE SOURCE -->
<div class="wrap">
  <header>
    <div class="container">
      <h1><a href="#">Student Information System</a></h1>
      <nav>
        <ul>
          <li><a href="index.php" class="m1">Home Page</a></li>
          <li><a href="index1.php" class="m2">Insert</a></li>
          <li class="current"><a href="index2.php" class="m4">Update and Delete</a></li>
		  <li><a href="viewcon.php" class="m4">Messages</a></li>
        </ul>
      </nav>
      
    </div>
  </header>
  <div class="container">
    <aside>
      <h3>Update and Delete</h3>
      <ul class="categories">
        <li><span><a href="search.php">Student</a></span></li>
        <li><span><a href="search1.php">Course</a></span></li>
        <li><span><a href="search2.php">Program</a></span></li>
		<li><span><a href="search3.php">Subject</a></span></li>
		
        
      </ul>
      
        <fieldset>
          <div class="rowElem">
            
            
          </div>
        </fieldset>
      
      
      
    </aside>
    <section id="content">
      <div id="banner">
        <h2>Student Information <span>North Lakhimpur College </span></h2>
      </div>
      
    </section>
  
</div>

</footer>
<script type="text/javascript"> Cufon.now(); </script>
<!-- END PAGE SOURCE -->
</body>
</html>