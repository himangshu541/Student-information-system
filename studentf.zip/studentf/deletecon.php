<?php
require 'dbh.inc.php';
$s_id = $_GET['s_id'];
$sql = 'DELETE FROM contact WHERE s_id=:s_id';
$statement = $connection->prepare($sql);
if ($statement->execute([':s_id' => $s_id])) {
  header("Location:viewcon.php");
}
