<?php
require 'dbh.inc.php';
$sub_id = $_GET['sub_id'];
$sql = 'DELETE FROM subject WHERE sub_id=:sub_id';
$statement = $connection->prepare($sql);
if ($statement->execute([':sub_id' => $sub_id])) {
  header("Location:search3.php");
}
