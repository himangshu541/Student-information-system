<!DOCTYPE html>
<html lang="en">
<head>
<title>Student Information</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.4.2.min.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_300.font.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_400.font.js"></script>
<script type="text/javascript" src="js/script.js"></script>

</head>
<body id="page1">
<!-- START PAGE SOURCE -->
<div class="wrap">
  <header>
    <div class="container">
      <h1><a href="#">Student Information System</a></h1>
      <nav>
        <ul>
          <li><a href="index.php" class="m1">Home Page</a></li>
          <li><a href="login.php" class="m2">Log In</a></li>
          <li class="current"><a href="contact.php" class="m4">Contact Us</a></li>
		  <li><a href="about.php" class="m4">About</a></li>
        </ul>
      </nav>
      
    </div>
  </header>
  
     <head>

       <title>Contact</title>
	   
	 </head>


<center><font size="5" color="blue">ADD UPDATING DETAILS</font></center>

<center>
<br>
<form action="contact.php" method="post">
<table width="420" height="100" align="center">

<br><br>

<tr> 
<td>STUDENT ID</td>
<td align="center"><input name="s_id" type="id" style="width:150px"></td>
</tr>

<tr> 
<td>UPDATING DETAILS</td>
<td align="center"><input name="message" type="text" style="width:150px"></td>
</tr>
 


<tr>
<td>&nbsp;</td>
<td align="center"><button type="submit" name="submit">SUBMIT</button></td></tr>

</table>
</form>

<?php
 if(isset($_POST['submit']))
	{
       
		
		$s_id = $_POST['s_id'];
		$message = $_POST['message'];
		
		
		
			$servername = "localhost";
			$username = "root";
			$password = "";
			$dbname = "stu_in";

		
			$conn = new mysqli($servername, $username, $password,$dbname);
			
			if(!$conn)
			{
				die("connection failed:".mysqli_connect_error());
			}
		
			
			$sql="INSERT INTO contact(s_id , message ) VALUES ('$s_id','$message')";
			
			
			if (mysqli_query($conn,$sql))
			{
				echo "New record inserted";
			}
			//else
			//{
				//echo "Eror:";
			//}
			//mysqli_close($conn);
		
	}
	
?>


</center>







<script type="text/javascript"> Cufon.now(); </script>
<!-- END PAGE SOURCE -->
</body>
</html>
