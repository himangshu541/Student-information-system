<!DOCTYPE html>
<html lang="en">
<head>
<title>Student Information</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.4.2.min.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_300.font.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_400.font.js"></script>
<script type="text/javascript" src="js/script.js"></script>

</head>
<body id="page1">
<!-- START PAGE SOURCE -->
<div class="wrap">
  <header>
    <div class="container">
      <h1><a href="#">Student Information System</a></h1>
      <nav>
        <ul>
          <li><a href="index.php" class="m1">Home Page</a></li>
          <li class="current"><a href="index1.php" class="m2">Insert</a></li>
          <li><a href="index2.php" class="m4">Delete And Update</a></li>
		  <li><a href="about.php" class="m4">About</a></li>
        </ul>
      </nav>
      
    </div>
  </header>
  <div class="container">
    <aside>
      <h3>Insert</h3>
      <ul class="categories">
        <li><span><a href="student.php">Student</a></span></li>
        <li><span><a href="course.php">Course</a></span></li>
        <li><span><a href="program.php">Program</a></span></li>
		<li><span><a href="subject.php">Subject</a></span></li>
		<li><span><a href="student_attendance.php">Attendance</a></span></li>
		<li><span><a href="student_course.php">Marks</a></span></li>
		<li><span><a href="student_subject.php">Student Subject</a></span></li>
        
      </ul>
      
        <fieldset>
          <div class="rowElem">
            
            
          </div>
        </fieldset>
      
      
      
    </aside>
  
     
    

  



<center><font size="5" color="blue">ADD STUDENT's ATTENDANCE DETAILS</font></center>

<center>
<br>
<form action="student_attendance.php" method="post">
<table width="400" height="200" align="center">

<br><br>

<tr> 
<td>STUDENT ROLL NO</td>
<td align="center"><input name="s_id" type="id" style="width:150px"></td>
</tr>

<tr> 
<td>COURSE ID</td>
<td align="center"><input name="course_id" type="text" style="width:150px"></td>
</tr>

<tr> 
<td>TOTAL CLASS</td>
<td align="center"><input name="t_class" type="text" style="width:150px"></td>
</tr>

<tr> 
<td>PRESENT CLASS</td>
<td align="center"><input name="p_class" type="text" style="width:150px"></td>
</tr>




<tr>
<td>&nbsp;</td>
<td align="center"><button type="submit" name="submit">SUBMIT</button></td></tr>

</table>
</form>

<?php
 if(isset($_POST['submit']))
	{
       
		
		$s_id = $_POST['s_id'];
		$course_id = $_POST['course_id'];
		$t_class = $_POST['t_class'];
		$p_class = $_POST['p_class'];
		
		$percent = ($p_class/$t_class)*100;
		
		
		
			$servername = "localhost";
			$username = "root";
			$password = "";
			$dbname = "stu_in";

		
			$conn = new mysqli($servername, $username, $password,$dbname);
			
			if(!$conn)
			{
				die("connection failed:".mysqli_connect_error());
			}
		
			
			$sql="INSERT INTO student_attendance(s_id , course_id , t_class , p_class , percent) VALUES ('$s_id','$course_id','$t_class','$p_class', '$percent')";
			
			
			if (mysqli_query($conn,$sql))
			{
				echo "New record inserted";
			}
			//else
			//{
				//echo "Eror:";
			//}
			//mysqli_close($conn);
		
	}
	
?>


</center>












<script type="text/javascript"> Cufon.now(); </script>
<!-- END PAGE SOURCE -->
</body>
</html>
