<html>
<head>	
<style>
	ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

li {
    float: left;
}

li a, .dropbtn {
    display: inline-block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover, .dropdown:hover .dropbtn {
    background-color: red;
}

li.dropdown {
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
    display: block;
}
</style>
</head>
<body>
<ul>
	<li><a class="active" href="index.php">HOME</a></li>
	<li><a class="active" href="contact.php">CONTACT US</a></li>
	<li><a class="active" href="about.php">ABOUT</a></li>
	
	
	
</ul>
 <?php
    if (isset($_POST['search'])) {
        $valueToSearch = $_POST['valueToSearch'];
		
        $query = "SELECT * FROM student WHERE s_id like  '%".$valueToSearch."%' or s_name like '%".$valueToSearch."%'";
		//CONCAT ('s_id', 's_name', 'address', 'phn_no', 'email', 'blood_group') LIKE '%".$valueToSearch."%'"; 
        $search_result = filterTable($query);
    } else {
            $query = "SELECT * FROM student";
            $search_result = filterTable($query);

    }

    function filterTable($query){
        $connect = mysqli_connect("localhost", "root", "", "stu_in");
        $filter_Result = mysqli_query($connect, $query);
        return $filter_Result;
    }
?>



   
<br><br><br><br>

<center><font size="5" color="black">Student Details</font></center>

<br><br><br><br>


<center><font size="5" color="black">Personal Details</font></center>


<BR>
    <table align="center" border=3 cellpadding=9 cellspacing=2>

    <tr>
        <th>ID</th>
		<th>NAME</th>
		<th>FATHER'S NAME</th>
		<th>ADDRESS</th>
		<th>PHN NO</th>
		<th>email</th>
		<th>BLOOD GROUP</th>
		<th>ADMISSION</th>
		<th>STREAM</th>
		<th>DOB</th>
		
		
    </tr>
    <?php
        //while($res = mysql_fetch_array($result)) { // mysql_fetch_array is deprecated, we need to use mysqli_fetch_array
          while($row = mysqli_fetch_array($search_result)) {         
            echo "<tr>";
			echo "<td>".$row['s_id']."</td>";
			echo "<td>".$row['s_name']."</td>";
			echo "<td>".$row['f_name']."</td>";
            echo "<td>".$row['address']."</td>";		
            echo "<td>".$row['phn_no']."</td>";
            echo "<td>".$row['email']."</td>";
            echo "<td>".$row['blood_group']."</td>";
			echo "<td>".$row['admission']."</td>";
			echo "<td>".$row['stream']."</td>";
			echo "<td>".$row['dob']."</td>";
			
			
                   
        }
		?>
</table>


<br><br><br>

<center><font size="5" color="black">Department Information</font></center>

<BR>

<?php
    if (isset($_POST['search'])) {
        $valueToSearch = $_POST['valueToSearch'];
        $query = "SELECT * FROM student_subject WHERE s_id like  '%".$valueToSearch."%' ";
		//CONCAT ('s_id', 's_name', 'address', 'phn_no', 'email', 'blood_group') LIKE '%".$valueToSearch."%'"; 
        $search_result = filterTable($query);
    } else {
            $query = "SELECT * FROM student_subject";
            $search_result = filterTable($query);

    }

   
    
?>
   <table align="center" border=3 cellpadding=9 cellspacing=2>

    <tr>
        
		<th>DEPARTMENT ID</th>
		<th>CORE </th>
		<th>NON CORE </th>
		
		
		
		
    </tr>
    <?php
        //while($res = mysql_fetch_array($result)) { // mysql_fetch_array is deprecated, we need to use mysqli_fetch_array
     
		  
		  while($row = mysqli_fetch_array($search_result)) {         
            echo "<tr>";
			
			echo "<td>".$row['sub_id']."</td>";
            echo "<td>".$row['core']."</td>";
			echo "<td>".$row['non_core']."</td>";
			
            
			
			
                   
        }
		?>
</table>


<br><br><br>

<center><font size="5" color="black">Attendance Information</font></center>

<BR>


<?php
    if (isset($_POST['search'])) {
        $valueToSearch = $_POST['valueToSearch'];
        $query = "SELECT * FROM student_attendance left join course on student_attendance.course_id=course.course_id WHERE s_id like  '%".$valueToSearch."%' ";
		//CONCAT ('s_id', 's_name', 'address', 'phn_no', 'email', 'blood_group') LIKE '%".$valueToSearch."%'"; 
        $search_result = filterTable($query);
    } else {
            $query = "SELECT * FROM student_attendance left join course on student_attendance.course_id=course.course_id";
            $search_result = filterTable($query);

    }

   
    
?>
   <table align="center" border=3 cellpadding=9 cellspacing=2>

    <tr>
        
		<th>COURSE ID</th>
		<th>COURSE NAME</th>
		<th>TOTAL CLASS</th>
		<th>PRESENT CLASS</th>
		<th>PERCENTAGE</th>
		
		
		
    </tr>
    <?php
        //while($res = mysql_fetch_array($result)) { // mysql_fetch_array is deprecated, we need to use mysqli_fetch_array
     
		  
		  while($row = mysqli_fetch_array($search_result)) {         
            echo "<tr>";
			
			echo "<td>".$row['course_id']."</td>";
			echo "<td>".$row['course_name']."</td>";
            echo "<td>".$row['t_class']."</td>";
			echo "<td>".$row['p_class']."</td>";
			echo "<td>".$row['percent']."</td>";
            
			
			
                   
        }
		?>
</table>


<br><br><br>

<center><font size="5" color="black">Marks Information</font></center>

<BR>


<?php
    if (isset($_POST['search'])) {
        $valueToSearch = $_POST['valueToSearch'];
         $query = "SELECT * FROM student_course left join course on student_course.course_id=course.course_id WHERE s_id like  '%".$valueToSearch."%' ";
		//CONCAT ('s_id', 's_name', 'address', 'phn_no', 'email', 'blood_group') LIKE '%".$valueToSearch."%'"; 
        $search_result = filterTable($query);
		
    } else {
            $query = "SELECT * FROM student_course left join course on student_course.course_id=course.course_id";
            $search_result = filterTable($query);

    }

    
?>
   <table align="center" border=3 cellpadding=9 cellspacing=2>

    <tr>
        
		<th>COURSE ID</th>
		<th>COURSE NAME</th>
		<th>1st SESSIONAL </th>
		<th>2nd SESSIONAL </th>
		<th>INTERNEL </th>
		<th>FINAL </th>
		
		
		
    </tr>
    <?php
        //while($res = mysql_fetch_array($result)) { // mysql_fetch_array is deprecated, we need to use mysqli_fetch_array
     
		  
		  while($row = mysqli_fetch_array($search_result)) {         
            echo "<tr>";
			
			echo "<td>".$row['course_id']."</td>";
			echo "<td>".$row['course_name']."</td>";
            echo "<td>".$row['first_ss']."</td>";
			echo "<td>".$row['second_ss']."</td>";
			echo "<td>".$row['internel']."</td>";
			echo "<td>".$row['final']."</td>";
            
			
			
                   
        }
		?>
</table>
</form>
</body>
</html>