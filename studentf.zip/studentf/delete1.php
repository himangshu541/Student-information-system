<?php
require 'dbh.inc.php';
$course_id = $_GET['course_id'];
$sql = 'DELETE FROM course WHERE course_id=:course_id';
$statement = $connection->prepare($sql);
if ($statement->execute([':course_id' => $course_id])) {
  header("Location:search1.php");
}
