-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 16, 2018 at 06:50 AM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `stu_in`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
`id` int(10) NOT NULL,
  `user_name` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `user_name`, `password`) VALUES
(1, 'admin', 'abc');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `s_id` varchar(10) NOT NULL,
  `message` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`s_id`, `message`) VALUES
('15BA001', 'hguigi'),
('15BC007', 'I have change my phone no. My new phone no is 8909876543');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE IF NOT EXISTS `course` (
  `course_id` varchar(10) NOT NULL,
  `course_name` varchar(50) NOT NULL,
  `credit` int(10) NOT NULL,
  `type` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`course_id`, `course_name`, `credit`, `type`) VALUES
('BA1', 'Major 1st Paper 1st', 4, 'written'),
('BA2', 'Major 2nd Paper 1st', 4, 'written'),
('BC12', 'Mathematics1', 3, 'written'),
('BC13', 'C Programming', 4, 'written'),
('BC14', 'Digital design', 3, 'written'),
('BC15', 'Unix Linux', 4, 'written'),
('BC16', 'Lab Practical1', 4, 'Practical'),
('BC21', 'Mathematics2', 4, 'written'),
('BC22', 'Data Structure', 4, 'written'),
('BC23', 'C++', 4, 'written'),
('BC24', 'Computer architectur', 4, 'written'),
('BC25', 'Lab Practical2', 4, 'Practical'),
('BC31', 'Finite Language Automata', 3, 'written'),
('BC32', 'Data Base Management System', 4, 'written'),
('BC33', 'Operating System', 4, 'written'),
('BC34', 'Computer Networks', 3, 'written'),
('BC35', 'Graph Theory', 2, 'written'),
('BC36', 'Lab Practical3', 4, 'Practical'),
('BC41', 'Computer Graphics', 3, 'written'),
('BC42', 'Numerical & Scientific Computing', 3, 'written'),
('BC43', 'Computer Networking', 4, 'written'),
('BC44', 'Web Technologies', 3, 'written'),
('BC45', 'System Software', 3, 'written'),
('BC46', 'Lab Practical4', 4, 'Practical'),
('BC47', 'Environmental Studies', 3, 'MCQ'),
('BC51', 'Algorithm', 4, 'written'),
('BC52', 'Software engineering', 4, 'written'),
('BC53', 'Artificial Intelligence', 4, 'written'),
('BC54', 'Minor Project', 8, 'Practical'),
('BC61', 'Opration Research', 3, 'written'),
('BC62', 'Unix', 2, 'written'),
('BC63', 'Major Project', 14, 'Practical'),
('BS1', 'Major 1st Paper 1st', 5, 'written'),
('BS10', 'Bootany 1st', 4, 'written'),
('BS11', 'Zoology 1st', 5, 'written'),
('BS2', 'Major 2nd Paper 1st', 5, 'written'),
('BS3', 'English 1st', 4, 'written'),
('BS4', 'Assamese 1st', 4, 'written'),
('BS5', 'Economics 1st', 3, 'written'),
('BS6', 'Chemistry 1st', 4, 'written'),
('BS7', 'Computer science 1st', 4, 'written'),
('BS8', 'Geography 1st', 4, 'written'),
('BS9', 'Mathematics 1st', 4, 'written');

-- --------------------------------------------------------

--
-- Table structure for table `details`
--

CREATE TABLE IF NOT EXISTS `details` (
  `name` varchar(30) NOT NULL,
  `pass` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `details`
--

INSERT INTO `details` (`name`, `pass`) VALUES
('admin', 'abc');

-- --------------------------------------------------------

--
-- Table structure for table `program`
--

CREATE TABLE IF NOT EXISTS `program` (
  `p_id` varchar(10) NOT NULL,
  `p_name` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `program`
--

INSERT INTO `program` (`p_id`, `p_name`) VALUES
('B.A', 'Bachelor of Arts'),
('B.Sc', 'Bachelor of Science'),
('BCA', 'Bachelor of Computer Science'),
('M.A', 'Masters in Arts');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `s_id` varchar(10) NOT NULL,
  `s_name` varchar(20) NOT NULL,
  `f_name` varchar(30) NOT NULL,
  `address` varchar(30) NOT NULL,
  `phn_no` varchar(10) NOT NULL,
  `email` varchar(20) NOT NULL,
  `blood_group` varchar(10) NOT NULL,
  `admission` varchar(20) NOT NULL,
  `stream` varchar(20) NOT NULL,
  `dob` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`s_id`, `s_name`, `f_name`, `address`, `phn_no`, `email`, `blood_group`, `admission`, `stream`, `dob`) VALUES
('15BA001', 'Pankaj Dutta', 'Jayanta Dutta', 'k.b road', '8578909541', 'jayanta1234@gmail.co', 'A-', '2015', 'Arts', '05/03/1997'),
('15BA003', 'Jodumoni Patir', 'Nani Patir', 'Majuli', '9987800065', 'jodu123@gmail.com', 'O+', '2015', 'Arts', '02/01/1997'),
('15BA004', 'Imaran Ahmed', 'Jakir Ahmed', 'c.d road', '7787966544', 'imran1213@gmail.com', 'A+', '2015', 'Arts', '06/05/1996'),
('15BA005', 'Tarali Hazarika', 'Tarun Hazarika', 'Laluk', '7786500099', 'tarali123@gmail.com', 'AB+', '2015', 'Arts', '04/09/1996'),
('15BA069', 'Hirak Jyoti Das', 'Lalit Das', 'khelmati', '8890976543', 'hirakj123@gmail.com', 'B+', '2015', 'Arts', '17/11/1996'),
('15BC007', 'Pranab Bora', 'Ltttttttttttttttttttttttttt', 'Laluk', '8723859421', 'prnbbora4@gmail.', 'O+', '2015', 'BCA', '25/03/1996'),
('15BS001', 'Samiran Hazarika', 'Dadul Hazarika', 'Panigaon', '9987390076', 'samiran123@gmail.com', 'AB+', '2015', 'Science', '04/04/1996'),
('15BS002', 'Barsha Dutta', 'Dilip Dutta', 'Ghilamora', '7896598543', 'barsaha123@gmail.com', 'O+', '2015', 'Science', '11/11/1996'),
('15BS003', 'Kishor Sonowal', 'Madhab Sonowal', 'Azad', '9879065476', 'kishore123@gmail.com', 'O+', '2015', 'Science', '05/12/1996'),
('15BS004', 'Manash Sarmah', 'Mrinal Sarmah', 'Narayanpur', '7578978632', 'manash123@gmail.com', 'A+', '2015', 'Science', '01/02/1997'),
('15BS005', 'Asish jyoti Boruah', 'Arun Boruah', 'Dhemaji', '8890976123', 'asisha122@gmail.com', 'A+', '2015', 'Science', '07/09/1996'),
('15BS209', 'Sourabh Jyoty Dutta', 'Ratul Dutta', 'Hindu Gaon', '8678987654', 'sourabh123@gmail.com', 'O+', '2015', 'Science', '18/04/1996'),
('15BS312', 'Dhiren Dutta', 'Gulap Dutta', 'Bahadurchuk', '9954333302', 'dhiren123@gmail.com', 'A+', '2015', 'Science', '01/07/1996'),
('15BS389', 'Dhueba Jyoti Sarmah', 'Ananda Sarmah', 'Chamua Gaon', '9876590987', 'dhurba123@gmail.com', 'AB+', '2015', 'Science', '16?01/1997'),
('16BA077', 'Pranab Bora', 'Ratul Bora', 'Pani Gaon', '9908600965', 'pranab1334@gmail.com', 'AB+', '2016', 'Arts', '11/04/2011'),
('16BA100', 'Farhan Akhtar', 'Nasir Akhtar', 'Laluk', '9988339900', 'Farhan123@gmail.com', 'O+', '2016', 'Arts', '09/09/1997'),
('16BS084', 'Mridul Dutta', 'Jagat Dutta', 'Pani Gaon', '9988776655', 'mridul123@gmail.com', 'A+', '2016', 'Science', '09/09/1998');

-- --------------------------------------------------------

--
-- Table structure for table `student_attendance`
--

CREATE TABLE IF NOT EXISTS `student_attendance` (
  `s_id` varchar(10) NOT NULL,
  `course_id` varchar(10) NOT NULL,
  `t_class` varchar(20) NOT NULL,
  `p_class` varchar(20) NOT NULL,
  `percent` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_attendance`
--

INSERT INTO `student_attendance` (`s_id`, `course_id`, `t_class`, `p_class`, `percent`) VALUES
('15BA001', 'BA1', '40', '30', '75%'),
('15BA001', 'BA2', '40', '20', '50%'),
('15BA069', 'BA1', '32', '32', '100%'),
('15BC007', 'BC12', '30', '30', '100%'),
('15BC007', 'BC13', '30', '25', '80%'),
('15BC007', 'BC14', '25', '20', '75%'),
('15BC007', 'BC15', '30', '15', '50%'),
('15BC007', 'BC16', '15', '15', '100%'),
('15BC007', 'BC31', '30', '23', '76.666666666667'),
('15BC007', 'BC32', '28', '21', '75'),
('15BC007', 'BC42', '33', '19', '57.575757575758'),
('15BC007', 'BC51', '34', '21', '61.764705882353'),
('15BS001', 'BS1', '30', '25', '75%'),
('15BS001', 'BS2', '30', '15', '50%'),
('15BS001', 'BS3', '25', '21', '83%'),
('15BS001', 'BS6', '28', '28', '100%'),
('15BS001', 'BS9', '20', '20', '100%'),
('16BS084', 'BS1', '29', '24', '82.758620689655');

-- --------------------------------------------------------

--
-- Table structure for table `student_course`
--

CREATE TABLE IF NOT EXISTS `student_course` (
  `s_id` varchar(10) NOT NULL,
  `course_id` varchar(10) NOT NULL,
  `first_ss` varchar(10) NOT NULL,
  `second_ss` varchar(10) NOT NULL,
  `internel` varchar(10) NOT NULL,
  `final` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_course`
--

INSERT INTO `student_course` (`s_id`, `course_id`, `first_ss`, `second_ss`, `internel`, `final`) VALUES
('15BA069', 'BA1', '13', '15', '40', '51'),
('15BC007', 'BC12', '13', '07', '33', '47'),
('15BC007', 'BC13', '17', '12', '39', '44'),
('15BC007', 'BC14', '09', '18', '42', '50'),
('15BC007', 'BC15', '12', '11', '31', '34'),
('15BC007', 'BC16', '-', '-', '-', '75'),
('16BS084', 'BS1', '20', '16', '33', '64'),
('16BS084', 'BS2', '18', '16', '31', '12');

-- --------------------------------------------------------

--
-- Table structure for table `student_subject`
--

CREATE TABLE IF NOT EXISTS `student_subject` (
  `s_id` varchar(10) NOT NULL,
  `sub_id` int(10) NOT NULL,
  `core` varchar(100) NOT NULL,
  `non_core` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_subject`
--

INSERT INTO `student_subject` (`s_id`, `sub_id`, `core`, `non_core`) VALUES
('15BA001', 4, 'Education', 'English, Assamese, Anthropology, History, Political Science, Economics'),
('15BA069', 4, 'Education', 'English, Assamese, Anthropology, History, Political Science, Economics'),
('15BC007', 1, '-', '-'),
('15BS001', 16, 'Physics', 'English, Chemistry, Mathematics'),
('15BS002', 7, 'Bootany', 'English, Zoology, Chemistry'),
('15BS003', 9, 'Chemistry', 'English, Physics, Mathematics'),
('15BS004', 19, 'Statictics', 'English, Mathematics, Physics'),
('15BS005', 20, 'Zoology', 'English, Bootany, Chemistry'),
('15BS209', 16, 'Physics', 'English, Math, Chemistry'),
('15BS312', 16, 'Physics', 'English, Math, Chemistry'),
('15BS389', 16, 'Physics', 'English, Math, Chemistry');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE IF NOT EXISTS `subject` (
`sub_id` int(10) NOT NULL,
  `sub_name` varchar(20) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`sub_id`, `sub_name`) VALUES
(1, 'Computer science'),
(2, 'Anthropology'),
(3, 'Assamese'),
(4, 'Education'),
(5, 'English'),
(6, 'Economics'),
(7, 'Bootany'),
(8, 'Electronics'),
(9, 'Chemistry'),
(11, 'Hindi'),
(12, 'History'),
(13, 'Home Science'),
(14, 'Mass Communication'),
(15, 'Political Science'),
(16, 'Physics'),
(17, 'Philosophy'),
(18, 'Physical Education'),
(19, 'Satistics'),
(20, 'Zoology'),
(22, 'H.S 1st Science'),
(23, 'H.S 2nd Arts'),
(24, 'H.S 2nd Science');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
 ADD PRIMARY KEY (`s_id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
 ADD PRIMARY KEY (`course_id`);

--
-- Indexes for table `details`
--
ALTER TABLE `details`
 ADD PRIMARY KEY (`name`);

--
-- Indexes for table `program`
--
ALTER TABLE `program`
 ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
 ADD PRIMARY KEY (`s_id`);

--
-- Indexes for table `student_attendance`
--
ALTER TABLE `student_attendance`
 ADD PRIMARY KEY (`s_id`,`course_id`), ADD KEY `s_id` (`s_id`), ADD KEY `course_id` (`course_id`);

--
-- Indexes for table `student_course`
--
ALTER TABLE `student_course`
 ADD PRIMARY KEY (`s_id`,`course_id`), ADD KEY `course_id` (`course_id`);

--
-- Indexes for table `student_subject`
--
ALTER TABLE `student_subject`
 ADD PRIMARY KEY (`s_id`,`sub_id`), ADD KEY `sub_id` (`sub_id`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
 ADD PRIMARY KEY (`sub_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
MODIFY `sub_id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=25;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `contact`
--
ALTER TABLE `contact`
ADD CONSTRAINT `contact_ibfk_1` FOREIGN KEY (`s_id`) REFERENCES `student` (`s_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `student_attendance`
--
ALTER TABLE `student_attendance`
ADD CONSTRAINT `student_attendance_ibfk_2` FOREIGN KEY (`s_id`) REFERENCES `student` (`s_id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `student_attendance_ibfk_3` FOREIGN KEY (`course_id`) REFERENCES `course` (`course_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `student_course`
--
ALTER TABLE `student_course`
ADD CONSTRAINT `student_course_ibfk_1` FOREIGN KEY (`s_id`) REFERENCES `student` (`s_id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `student_course_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `course` (`course_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `student_subject`
--
ALTER TABLE `student_subject`
ADD CONSTRAINT `student_subject_ibfk_1` FOREIGN KEY (`sub_id`) REFERENCES `subject` (`sub_id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `student_subject_ibfk_2` FOREIGN KEY (`s_id`) REFERENCES `student` (`s_id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
