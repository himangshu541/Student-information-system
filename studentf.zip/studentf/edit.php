<!DOCTYPE html>
<html lang="en">
<head>
<title>Student Information</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.4.2.min.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_300.font.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_400.font.js"></script>
<script type="text/javascript" src="js/script.js"></script>

</head>
<body id="page1">
<!-- START PAGE SOURCE -->
<div class="wrap">
  <header>
    <div class="container">
      <h1><a href="#">Student Information System</a></h1>
      <nav>
        <ul>
          <li><a href="index.php" class="m1">Home Page</a></li>
          <li class="current"><a href="index1.php" class="m2">Insert</a></li>
          <li><a href="#.php" class="m4">Delete And Update</a></li>
		  <li><a href="about.html" class="m4">About</a></li>
        </ul>
      </nav>
      
    </div>
  </header>
  
  
<head>
    <title>	view student details</title>
	
</head>	


  <section>
  <center> <br> <font size="6" color="maroon" face="times new roman">VIEW  AND UPDATE DETAILS</font><br/><br/>
  <br><br><br><br>
<?php
require 'dbh.inc.php';
$s_id = $_GET['s_id'];
$sql = 'SELECT * FROM student WHERE s_id=:s_id';
$statement = $connection->prepare($sql);
$statement->execute([':s_id' => $s_id ]);
$product = $statement->fetch(PDO::FETCH_OBJ);

if (isset ($_POST['s_name']) && isset($_POST['f_name']) && isset($_POST['address']) && isset($_POST['phn_no']) && isset($_POST['email']) && isset($_POST['blood_group'])&& isset($_POST['admission'])&& isset($_POST['stream'])&& isset($_POST['dob'])) {
  $s_name = $_POST['s_name'];
  $f_name = $_POST['f_name'];
  $address = $_POST['address'];
  $phn_no = $_POST['phn_no'];
  $email = $_POST['email'];
  $blood_group= $_POST['blood_group'];
  $admission = $_POST['admission'];
  $stream = $_POST['stream'];
  $dob = $_POST['dob'];
  $sql = 'UPDATE student SET s_name=:s_name, f_name=:f_name, address=:address, phn_no=:phn_no, email=:email, blood_group=:blood_group, admission=:admission, stream=:stream, dob=:dob WHERE s_id=:s_id';
  $statement = $connection->prepare($sql);
  if ($statement->execute([':s_name' => $s_name, ':f_name' => $f_name, ':address' => $address, ':phn_no' => $phn_no, ':email' => $email, ':blood_group' => $blood_group, ':admission' => $admission, ':stream' => $stream, ':dob' => $dob, ':s_id' => $s_id])) {
    header("Location:search.php");
  }
}
 ?>

      <h2>Update student</h2>
      <?php if(!empty($message)): ?>
        <div class="alert alert-success">
          <?= $message; ?>
        </div>
		
		
      <?php endif; ?>
      <form method="post">
        <div class="form-group">
          <label for="s_name">Name</label>
          <input value="<?= $product->s_name; ?>" type="text" name="s_name" id="s_name" size="50">
        </div><br>
		
		<div class="form-group">
          <label for="f_name">FATHER'S NAME</label>
          <input type="text" value="<?= $product->f_name; ?>" name="f_name" id="f_name" size="50">
        </div><br>
		
        <div class="form-group">
          <label for="address">Address</label>
          <input type="text" value="<?= $product->address; ?>" name="address" id="address" size="50">
        </div><br>
		
		<div class="form-group">
          <label for="phn_no">Phn no</label>
          <input type="text" value="<?= $product->phn_no; ?>" name="phn_no" id="phn_no" size="50">
        </div><br>
		
		<div class="form-group">
          <label for="email">Email</label>
          <input type="text" value="<?= $product->email; ?>" name="email" id="email" size="50">
        </div><br>
		
		
		<div class="form-group">
          <label for="blood_group">Blood Group</label>
          <input type="text" value="<?= $product->blood_group; ?>" name="blood_group" id="blood_group" size="50">
        </div><br>
		
		<div class="form-group">
          <label for="admission">Admission</label>
          <input type="text" value="<?= $product->admission; ?>" name="admission" id="admission" size="50">
        </div><br>
		
		<div class="form-group">
          <label for="stream">STREAM</label>
          <input type="text" value="<?= $product->stream; ?>" name="stream" id="stream" size="50">
        </div><br>
		
		<div class="form-group">
          <label for="dob">DOB</label>
          <input type="text" value="<?= $product->dob; ?>" name="dob" id="dob" size="50">
        </div><br>
		
        <div class="form-group">
          <button type="submit">Update student</button>
        </div>
		
      </form>
    </div>
  </div>
</div>


    









<script type="text/javascript"> Cufon.now(); </script>
<!-- END PAGE SOURCE -->
</body>
</html>
