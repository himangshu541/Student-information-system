<html>
<head>	
<style>
	ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

li {
    float: left;
}

li a, .dropbtn {
    display: inline-block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover, .dropdown:hover .dropbtn {
    background-color: red;
}

li.dropdown {
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
    display: block;
}
</style>
</head>
<body>
<ul>
	<li><a class="active" href="index.php">HOME</a></li>
	<li><a class="active" href="index1.php">INSERT</a></li>
	<li><a class="active" href="index2.php">UPDATE AND DELETE</a></li>
	<li><a class="active" href="#.php">MESSAGE</a></li>
	
	
</ul>
<?php
    if (isset($_POST['search'])) {
        $valueToSearch = $_POST['valueToSearch'];
		
        $query = "SELECT * FROM student WHERE s_id like  '%".$valueToSearch."%' or s_name like '%".$valueToSearch."%'";
		//CONCAT ('s_id', 's_name', 'address', 'phn_no', 'email', 'blood_group') LIKE '%".$valueToSearch."%'"; 
        $search_result = filterTable($query);
    } else {
            $query = "SELECT * FROM student";
            $search_result = filterTable($query);

    }

    function filterTable($query){
        $connect = mysqli_connect("localhost", "root", "", "stu_in");
        $filter_Result = mysqli_query($connect, $query);
        return $filter_Result;
    }
?>




   
<br><br><br><br>

<center><font size="5" color="black">Student Details</font></center>

<br><br><br><br>


<center><font size="5" color="black">Personal Details</font></center>


<BR>
    <table align="center" border=3 cellpadding=9 cellspacing=2>

    <tr>
        <th>ID</th>
		<th>NAME</th>
		<th>FATHER'S NAME</th>
		<th>ADDRESS</th>
		<th>PHN NO</th>
		<th>email</th>
		<th>BLOOD GROUP</th>
		<th>ADMISSION</th>
		<th>STREAM</th>
		<th>DOB</th>
		<th>update</th>
		<th>Delete</th>
		
		
    </tr>
    <?php
        //while($res = mysql_fetch_array($result)) { // mysql_fetch_array is deprecated, we need to use mysqli_fetch_array
          while($row = mysqli_fetch_array($search_result)) {         
            echo "<tr>";
			echo "<td>".$row['s_id']."</td>";
			echo "<td>".$row['s_name']."</td>";
			echo "<td>".$row['f_name']."</td>";
            echo "<td>".$row['address']."</td>";		
            echo "<td>".$row['phn_no']."</td>";
            echo "<td>".$row['email']."</td>";
            echo "<td>".$row['blood_group']."</td>";
			echo "<td>".$row['admission']."</td>";
			echo "<td>".$row['stream']."</td>";
			echo "<td>".$row['dob']."</td>";
			
			 echo "<td> <a href=\"edit.php?s_id=$row[s_id]\">Update</a></td>";                    	
            echo "<td> <a href=\"delete.php?s_id=$row[s_id]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";        
			
			
                   
        }
		?>
</table>
</html>