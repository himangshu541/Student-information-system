<!DOCTYPE html>
<html lang="en">
<head>
<title>Student Information</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.4.2.min.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_300.font.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_400.font.js"></script>
<script type="text/javascript" src="js/script.js"></script>

</head>
<body id="page1">
<!-- START PAGE SOURCE -->
<div class="wrap">
  <header>
    <div class="container">
      <h1><a href="#">Student Information System</a></h1>
      <nav>
        <ul>
          <li><a href="index.php" class="m1">Home Page</a></li>
          <li class="current"><a href="index1.php" class="m2">Insert</a></li>
          <li><a href="index2.php" class="m4">Delete And Update</a></li>
		  <li><a href="about.php" class="m4">About</a></li>
        </ul>
      </nav>
      
    </div>
  </header>
  <div class="container">
    <aside>
      <h3>Insert</h3>
      <ul class="categories">
        <li><span><a href="student.php">Student</a></span></li>
        <li><span><a href="course.php">Course</a></span></li>
        <li><span><a href="program.php">Program</a></span></li>
		<li><span><a href="subject.php">Subject</a></span></li>
		<li><span><a href="student_attendance.php">Attendance</a></span></li>
		<li><span><a href="student_course.php">Marks</a></span></li>
		<li><span><a href="student_subject.php">Student Subject</a></span></li>
        
      </ul>
      
        <fieldset>
          <div class="rowElem">
            
            
          </div>
        </fieldset>
      
      
      
    </aside>
     
    

  




     <head>

       <title>student details</title>
	   
	 </head>





<center><font size="5" color="blue">ADD STUDENT AND SUBJECT DETAILS</font></center>

<center>
<br>
<form action="student_subject.php" method="post">
<table width="420" height="150" align="center">

<br><br>
<tr> 
<td>STUDENT ID</td>
<td align="center"><input name="s_id" type="text" style="width:150px"></td>
</tr>

<tr> 
<td>DEPARTMENT ID</td>
<td align="center"><input name="sub_id" type="text" style="width:150px"></td>
</tr>

<tr> 
<td>CORE</td>
<td align="center"><input name="core" type="text" style="width:150px"></td>
</tr>

<tr> 
<td>NON CORE</td>
<td align="center"><input name="non_core" type="" style="width:150px"></td>
</tr>


<tr>
<td>&nbsp;</td>
<td align="center"><button type="submit" name="submit">SUBMIT</button></td></tr>

</table>
</form>

<?php
 if(isset($_POST['submit']))
	{
       
		
		$s_id = $_POST['s_id'];
		$sub_id = $_POST['sub_id'];
		$core = $_POST['core'];
		$non_core = $_POST['non_core'];
		
		
			$servername = "localhost";
			$username = "root";
			$password = "";
			$dbname = "stu_in";

		
			$conn = new mysqli($servername, $username, $password,$dbname);
			
			if(!$conn)
			{
				die("connection failed:".mysqli_connect_error());
			}
		
			
			$sql="INSERT INTO student_subject(s_id , sub_id , core , non_core ) VALUES ('$s_id','$sub_id','$core','$non_core')";
			
			
			if (mysqli_query($conn,$sql))
			{
				echo "New record inserted";
			}
			//else
			//{
				//echo "Eror:";
			//}
			//mysqli_close($conn);
		
	}
	
?>


</center>












<script type="text/javascript"> Cufon.now(); </script>
<!-- END PAGE SOURCE -->
</body>
</html>
