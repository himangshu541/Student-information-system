<!DOCTYPE html>
<html lang="en">
<head>
<title>Student Information</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.4.2.min.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_300.font.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_400.font.js"></script>
<script type="text/javascript" src="js/script.js"></script>

</head>
<body id="page1">
<!-- START PAGE SOURCE -->
<div class="wrap">
  <header>
    <div class="container">
      <h1><a href="#">Student Information System</a></h1>
      <nav>
        <ul>
          <li><a href="index.php" class="m1">Home Page</a></li>
          <li><a href="index1.php" class="m2">Insert</a></li>
          <li class="current">><a href="index2.php" class="m4">Delete And Update</a></li>
		  <li><a href="about.html" class="m4">About</a></li>
        </ul>
      </nav>
      
    </div>
  </header>
   <div class="container">
    <aside>
      <h3>Update and Delete</h3>
      <ul class="categories">
        <li><span><a href="search.php">Student</a></span></li>
        <li><span><a href="search1.php">Course</a></span></li>
        <li><span><a href="search2.php">Program</a></span></li>
		<li><span><a href="search3.php">Subject</a></span></li>
		
        
      </ul>
      
        <fieldset>
          <div class="rowElem">
            
            
          </div>
        </fieldset>
      
      
      
    </aside>
  
    <?php
    if (isset($_POST['search'])) {
        $Search = $_POST['Search'];
        $query = "SELECT * FROM course WHERE course_id like  '%".$Search."%' or course_name like '%".$Search."%'";
		//CONCAT ('course_id', 'course_name', 'credit') LIKE '%".$valueToSearch."%'"; 
        $search_result = filterTable($query);
    } else {
            $query = "SELECT * FROM course";
            $search_result = filterTable($query);

    }

    function filterTable($query){
        $connect = mysqli_connect("localhost", "root", "", "stu_in");
        $filter_Result = mysqli_query($connect, $query);
        return $filter_Result;
    }
?>





   
<br><br><br><br>

<center><font size="5" color="black">Course Details</font></center>

<br><br><br><br>

<center>
<form action="cview.php" method="POST">
<input type="text" name="valueToSearch" placeholder="Search Course">
<input type="submit" name="search" value="Search">
</center>
<BR><BR>
    
</form>









<script type="text/javascript"> Cufon.now(); </script>
<!-- END PAGE SOURCE -->
</body>
</html>
