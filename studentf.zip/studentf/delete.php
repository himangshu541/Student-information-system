<?php
require 'dbh.inc.php';
$s_id = $_GET['s_id'];
$sql = 'DELETE FROM student WHERE s_id=:s_id';
$statement = $connection->prepare($sql);
if ($statement->execute([':s_id' => $s_id])) {
  header("Location:search.php");
}
