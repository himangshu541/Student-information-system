<?php
    $dbServername = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbName = "stu_in";

    $conn=mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);
?>


<?php
$dsn = 'mysql:host=localhost;dbname=stu_in';
$username = 'root';
$password = '';
$options = [];
try {
$connection = new PDO($dsn, $username, $password, $options);
} catch(PDOException $e) {
}
