<!DOCTYPE html>
<html lang="en">
<head>
<title>Student Information</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.4.2.min.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_300.font.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_400.font.js"></script>
<script type="text/javascript" src="js/script.js"></script>

</head>
<body id="page1">
<!-- START PAGE SOURCE -->
<div class="wrap">
  <header>
    <div class="container">
      <h1><a href="#">Student Information System</a></h1>
      <nav>
        <ul>
          <li><a href="index.php" class="m1">Home Page</a></li>
          <li class="current"><a href="login.php" class="m2">Log In</a></li>
          <li><a href="contact.php" class="m4">Contact Us</a></li>
		  <li><a href="about.php" class="m4">About</a></li>
        </ul>
      </nav>
      
    </div>
  </header>
  <?php
session_start();
?>


<?php
error_reporting(1);
include("config.php");
$name=$_REQUEST['t1'];
$pass=$_REQUEST['p1'];

if($_REQUEST['sub'])
 {
 $sel=mysql_query("select name,pass from details where name='$name'");
 $arr=mysql_fetch_array($sel);
 if($arr['name']==$name and $arr['pass']==$pass)
   {
   session_start();
   $_SESSION['eid']=$name;
  header("location:index1.php");
  }
  else
   {
     $er="name and password do not match";
	 }
}	 
?>

<head>

</head>


<div><br><h1 align="center">ADMINISTRATOR LOGIN</h1>
</div>

<br><br><br><br><br>
<div  align="center" >
<center>
<br>
<table width="200" border="0" align="center">
<form method="post" name="f1" onSubmit="return vali()">
<tr><td colspan="2"><?php echo "<font color='red'>$er</font>";?></td></tr>
  <tr>
    <td width="81">UserName:</td>
    <td width="103"><label>
      <input name="t1" type="text" id="t1" onChange="return nam()">
    </label></td>
  </tr>
  <tr>
    <td>Password:</td>
    <td><input name="p1" type="password" id="p1" onChange="return pass()"></td>
  </tr>
 
  <tr>
    <td colspan="2" align="center"><label>
      <input name="sub" type="submit" id="sub" value="Login">
    </label></td>
   
  </form>
</table>
</fieldset></center>
</div>





<script type="text/javascript"> Cufon.now(); </script>
<!-- END PAGE SOURCE -->
</body>
</html>
