<!DOCTYPE html>
<html lang="en">
<head>
<title>Student Information</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.4.2.min.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_300.font.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_400.font.js"></script>
<script type="text/javascript" src="js/script.js"></script>

</head>
<body id="page1">
<!-- START PAGE SOURCE -->
<div class="wrap">
  <header>
    <div class="container">
      <h1><a href="#">Student Information System</a></h1>
      <nav>
        <ul>
          <li><a href="index.php" class="m1">Home Page</a></li>
          <li><a href="login.php" class="m2">LOg In</a></li>
          <li><a href="contact.php" class="m4">Contact Us</a></li>
		  <li><a href="about.php" class="m4">About</a></li>
        </ul>
      </nav>
      
    </div>
  </header>
  <div class="container">
    <aside>
      <h3>Search by</h3>
      <ul class="categories">
        <li><span><a href="searchx.php">By Roll No</a></span></li>
        <li><span><a href="searchnam.php">By Name</a></span></li>
		<li><span><a href="searchd.php">By Department</a></span></li>
        <li><span><a href="searchbl.php">By Blood Group</a></span></li>
        
      </ul>
      
        <fieldset>
          <div class="rowElem">
            
            
          </div>
        </fieldset>
      
      
      
    </aside>
	<?php
    if (isset($_POST['search'])) {
        $valueToSearch = $_POST['valueToSearch'];
        $query = "SELECT * FROM student_subject left join student on student_subject.s_id=student.s_id WHERE core like  '%".$valueToSearch."%' ";
		//or sub_name like '%".$valueToSearch."%'";
		//CONCAT ('s_id', 's_name', 'address', 'phn_no', 'email', 'blood_group') LIKE '%".$valueToSearch."%'"; 
        $search_result = filterTable($query);
    } else {
            $query = "SELECT * FROM student_subject left join student on student_subject.s_id=student.s_id";
            $search_result = filterTable($query);

    }

    function filterTable($query){
        $connect = mysqli_connect("localhost", "root", "", "stu_in");
        $filter_Result = mysqli_query($connect, $query);
        return $filter_Result;
    }
?>




   
<br><br><br><br>

<center><font size="5" color="black">Student Details</font></center>

<br><br><br><br>

<center>
<form action="viewd.php" method="POST">
<input type="text" name="valueToSearch" placeholder="Search Department">
<input type="submit" name="search" value="Search">
</center>
<BR><BR>


</form>
	
	
	
	
	<script type="text/javascript"> Cufon.now(); </script>
<!-- END PAGE SOURCE -->
</body>
</html>