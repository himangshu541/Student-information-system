<!DOCTYPE html>
<html lang="en">
<head>
<title>Student Information</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.4.2.min.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_300.font.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_400.font.js"></script>
<script type="text/javascript" src="js/script.js"></script>

</head>
<body id="page1">
<!-- START PAGE SOURCE -->
<div class="wrap">
  <header>
    <div class="container">
      <h1><a href="#">Student Information System</a></h1>
      <nav>
        <ul>
          <li><a href="index.php" class="m1">Home Page</a></li>
          <li class="current"><a href="index1.php" class="m2">Insert</a></li>
          <li><a href="#.php" class="m4">Delete And Update</a></li>
		  <li><a href="about.html" class="m4">About</a></li>
        </ul>
      </nav>
      
    </div>
  </header>
  
  


    <title>	view Program details</title>
	
</head>	


  <section>
  <center> <br> <font size="6" color="maroon" face="times new roman">VIEW  AND UPDATE DETAILS</font><br/><br/>
  <br><br><br><br>
<?php
require 'dbh.inc.php';
$p_id = $_GET['p_id'];
$sql = 'SELECT * FROM program WHERE p_id=:p_id';
$statement = $connection->prepare($sql);
$statement->execute([':p_id' => $p_id ]);
$product = $statement->fetch(PDO::FETCH_OBJ);

if (isset ($_POST['p_name']) ) {
  $p_name = $_POST['p_name'];
  $sql = 'UPDATE program SET p_name=:p_name WHERE p_id=:p_id';
  $statement = $connection->prepare($sql);
  if ($statement->execute([':p_name' => $p_name, ':p_id' => $p_id])) {
    header("Location:search2.php");
  }
}
 ?>

      <h2>Update Program or Paper</h2>
      <?php if(!empty($message)): ?>
        <div class="alert alert-success">
          <?= $message; ?>
        </div>
		
		
      <?php endif; ?>
      <form method="post">
        <div class="form-group">
          <label for="p_name">Name</label>
          <input value="<?= $product->p_name; ?>" type="text" name="p_name" id="p_name" size="50">
        </div><br>
		
        
		
        <div class="form-group">
          <button type="submit">Update student</button>
        </div>
		
      </form>
    </div>
  </div>
</div>


    
 




    









<script type="text/javascript"> Cufon.now(); </script>
<!-- END PAGE SOURCE -->
</body>
</html>
