<!DOCTYPE html>
<html lang="en">
<head>
<title>Student Information</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.4.2.min.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_300.font.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_400.font.js"></script>
<script type="text/javascript" src="js/script.js"></script>

</head>
<body id="page1">
<!-- START PAGE SOURCE -->
<div class="wrap">
  <header>
    <div class="container">
      <h1><a href="#">Student Information System</a></h1>
      <nav>
        <ul>
          <li class="current"><a href="index.php" class="m1">Home Page</a></li>
          <li><a href="login.php" class="m2">Log In</a></li>
          <li><a href="contact.php" class="m4">Contact Us</a></li>
		  <li><a href="about.php" class="m4">About</a></li>
        </ul>
      </nav>
      
    </div>
  </header>
  <div class="container">
    <aside>
      <h3>Search</h3>
      <ul class="categories">
        <li><span><a href="searchx.php">By Roll No</a></span></li>
        <li><span><a href="searchnam.php">By Name</a></span></li>
		<li><span><a href="searchd.php">By Department</a></span></li>
        <li><span><a href="searchbl.php">By Blood Group</a></span></li>
        
      </ul>
      
        <fieldset>
          <div class="rowElem">
            
            
          </div>
        </fieldset>
      
      
      
    </aside>
    <section id="content">
      <div id="banner">
        <h2>Student Information <span>North Lakhimpur College </span></h2>
      </div>
      <div class="inside">
        
       
    </section>
  </div>
</div>
<footer>
  <div class="footerlink">
    <p class="lf">Major Project </p>
    <p class="rf">Design by <a href="http://www.templatemonster.com/">Himangshu Kaushik</a></p>
    <div style="clear:both;"></div>
  </div>
</footer>
<script type="text/javascript"> Cufon.now(); </script>
<!-- END PAGE SOURCE -->
</body>
</html>
