<!DOCTYPE html>
<html lang="en">
<head>
<title>Student Information</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.4.2.min.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_300.font.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_400.font.js"></script>
<script type="text/javascript" src="js/script.js"></script>

</head>
<body id="page1">
<!-- START PAGE SOURCE -->
<div class="wrap">
  <header>
    <div class="container">
      <h1><a href="#">Student Information System</a></h1>
      <nav>
        <ul>
          <li><a href="index.php" class="m1">Home Page</a></li>
          <li class="current"><a href="index1.php" class="m2">Insert</a></li>
          <li><a href="#.php" class="m4">Delete And Update</a></li>
		  <li><a href="about.html" class="m4">About</a></li>
        </ul>
      </nav>
      
    </div>
  </header>
  
  



<head>
    <title>	view Department details</title>
	
</head>	


  <section>
  <center> <br> <font size="6" color="maroon" face="times new roman">VIEW  AND UPDATE DETAILS</font><br/><br/>
  <br><br><br><br>
<?php
require 'dbh.inc.php';
$sub_id = $_GET['sub_id'];
$sql = 'SELECT * FROM subject WHERE sub_id=:sub_id';
$statement = $connection->prepare($sql);
$statement->execute([':sub_id' => $sub_id ]);
$product = $statement->fetch(PDO::FETCH_OBJ);

if (isset ($_POST['sub_name']) ) {
  $sub_name = $_POST['sub_name'];
  $sql = 'UPDATE subject SET sub_name=:sub_name WHERE sub_id=:sub_id';
  $statement = $connection->prepare($sql);
  if ($statement->execute([':sub_name' => $sub_name, ':sub_id' => $sub_id])) {
    header("Location:search3.php");
  }
}
 ?>

      <h2>Update Department</h2>
      <?php if(!empty($message)): ?>
        <div class="alert alert-success">
          <?= $message; ?>
        </div>
		
		
      <?php endif; ?>
      <form method="post">
        <div class="form-group">
          <label for="sub_name">Department Name</label>
          <input value="<?= $product->sub_name; ?>" type="text" name="sub_name" id="sub_name" size="50">
        </div><br>
		
        
		
        <div class="form-group">
          <button type="submit">Update Department</button>
        </div>
		
      </form>
    </div>
  </div>
</div>


    
    
 




    









<script type="text/javascript"> Cufon.now(); </script>
<!-- END PAGE SOURCE -->
</body>
</html>
