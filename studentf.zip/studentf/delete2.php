<?php
require 'dbh.inc.php';
$p_id = $_GET['p_id'];
$sql = 'DELETE FROM program WHERE p_id=:p_id';
$statement = $connection->prepare($sql);
if ($statement->execute([':p_id' => $p_id])) {
  header("Location:search2.php");
}
