<!DOCTYPE html>
<html lang="en">
<head>
<title>Student Information</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.4.2.min.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_300.font.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_400.font.js"></script>
<script type="text/javascript" src="js/script.js"></script>

</head>
<body id="page1">
<!-- START PAGE SOURCE -->
<div class="wrap">
  <header>
    <div class="container">
      <h1><a href="#">Student Information System</a></h1>
      <nav>
        <ul>
          <li><a href="index.php" class="m1">Home Page</a></li>
          <li class="current"><a href="index1.php" class="m2">Insert</a></li>
          <li><a href="#.php" class="m4">Delete And Update</a></li>
		  <li><a href="about.html" class="m4">About</a></li>
        </ul>
      </nav>
      
    </div>
  </header>
  
  

<head>
    <title>	view Course details</title>
	
</head>	


  <section>
  <center> <br> <font size="6" color="maroon" face="times new roman">VIEW  AND UPDATE DETAILS</font><br/><br/>
  <br><br><br><br>
<?php
require 'dbh.inc.php';
$course_id = $_GET['course_id'];
$sql = 'SELECT * FROM course WHERE course_id=:course_id';
$statement = $connection->prepare($sql);
$statement->execute([':course_id' => $course_id ]);
$product = $statement->fetch(PDO::FETCH_OBJ);

if (isset ($_POST['course_name'])  && isset($_POST['credit'])) {
  $course_name = $_POST['course_name'];
  $credit = $_POST['credit'];
  $sql = 'UPDATE course SET course_name=:course_name, credit=:credit WHERE course_id=:course_id';
  $statement = $connection->prepare($sql);
  if ($statement->execute([':course_name' => $course_name, ':credit' => $credit,  ':course_id' => $course_id])) {
    header("Location:search1.php");
  }
}
 ?>

      <h2>Update course</h2>
      <?php if(!empty($message)): ?>
        <div class="alert alert-success">
          <?= $message; ?>
        </div>
		
		
      <?php endif; ?>
      <form method="post">
        <div class="form-group">
          <label for="course_name">Course Name</label>
          <input value="<?= $product->course_name; ?>" type="text" name="course_name" id="course_name" size="50">
        </div><br>
		
        <div class="form-group">
          <label for="credit">Credit</label>
          <input type="text" value="<?= $product->credit; ?>" name="credit" id="credit" size="50">
        </div><br>
		
		
		
        <div class="form-group">
          <button type="submit">Update student</button>
        </div>
		
      </form>
    </div>
  </div>
</div>




    









<script type="text/javascript"> Cufon.now(); </script>
<!-- END PAGE SOURCE -->
</body>
</html>
